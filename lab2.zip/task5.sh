#!/bin/bash
#PBS -N mpi_task5
#PBS -l nodes=2:ppn=2
#PBS -t 1

ml icc
ml openmpi

cd $PBS_O_WORKDIR

for i in {1..100}; do
  mpirun -np 4 ./hello
  if [ $i -lt 100 ]; then
    qsub -v COUNTER=$i ./task5.sh
  fi
done

if [ "$COUNTER" -eq "99" ]; then
  ./analyze_outputs.sh
fi
