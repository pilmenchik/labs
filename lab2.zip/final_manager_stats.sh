#!/bin/bash
cat manager_stats_*.txt > final_manager_stats.txt
