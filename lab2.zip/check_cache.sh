#!/bin/bash
lscpu | grep "L3 cache"
