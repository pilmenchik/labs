#!/bin/bash
#PBS -N mpi_task6
#PBS -l nodes=2:ppn=2
#PBS -t 1-50

ml icc
ml openmpi

cd $PBS_O_WORKDIR

if [ $((PBS_ARRAYID % 2)) -eq 0 ]; then
  ./collect_and_run.sh $PBS_ARRAYID
else
  mpirun -np 4 ./hello > ~/output_$PBS_ARRAYID.txt
fi

if [ "$PBS_ARRAYID" -eq "50" ]; then
  ./final_collect_and_analyze.sh
fi
