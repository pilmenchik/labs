#!/bin/bash
for file in combined_output_*.txt; do
  cat $file >> final_combined_output.txt
done
