#!/bin/bash
for file in /tmp/output_*.txt; do
  cat $file >> final_output.txt
done
