#!/bin/bash
#PBS -N mpi_task4
#PBS -l nodes=2:ppn=2

ml icc
ml openmpi

cd $PBS_O_WORKDIR

while true; do
  mpirun -np 4 ./hello
  ./update_stats.sh
  sleep 60
done
