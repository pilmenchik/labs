#!/bin/bash
cat intermediate_stats_*.txt > final_intermediate_stats.txt
