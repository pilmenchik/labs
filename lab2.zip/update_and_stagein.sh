#!/bin/bash
id=$1
for node in $(cat $PBS_NODEFILE | sort | uniq); do
  ssh $node "pgrep -c hello > stagein_$id.txt"
done
