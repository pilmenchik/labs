#!/bin/bash
#PBS -N mpi_task3
#PBS -l nodes=2:ppn=2
#PBS -t 1-100

ml icc
ml openmpi

cd $PBS_O_WORKDIR

./check_cache.sh > cache_$PBS_ARRAYID.txt

mpirun -np 4 ./hello > ~/output_$PBS_ARRAYID.txt

if [ "$PBS_ARRAYID" -eq "100" ]; then
  ./analyze_cache_and_outputs.sh
fi
