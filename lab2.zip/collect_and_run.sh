#!/bin/bash
id=$1
for i in $(seq $((id-1)) $id); do
  cat ~/output_$i.txt >> combined_output_$id.txt
done

mpirun -np 4 ./hello > ~/output_$((id+50)).txt
