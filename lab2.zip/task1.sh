#!/bin/bash
#PBS -N mpi_task1
#PBS -l nodes=2:ppn=2
#PBS -t 1-100

ml icc
ml openmpi

cd $PBS_O_WORKDIR

mpirun -np 4 ./hello > /tmp/output_$PBS_ARRAYID.txt

if [ "$PBS_ARRAYID" -eq "100" ]; then
  sleep 30
  ./analyze_outputs.sh
fi
