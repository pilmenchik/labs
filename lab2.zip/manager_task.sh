#!/bin/bash
id=$1
for i in $(seq $((($id - 1) * 10 + 1)) $(($id * 10))); do
  cat /tmp/output_$i.txt >> manager_stats_$id.txt
done
