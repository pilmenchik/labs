#!/bin/bash
id=$1
for i in $(seq $((id-9)) $id); do
  cat /tmp/output_$i.txt >> intermediate_stats_$id.txt
done
