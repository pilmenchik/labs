#!/bin/bash
for node in $(cat $PBS_NODEFILE | sort | uniq); do
  echo -n "$node: "
  ssh $node "pgrep -c hello"
done > process_stats.txt
