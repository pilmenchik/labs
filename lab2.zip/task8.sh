#!/bin/bash
#PBS -N mpi_task8
#PBS -l nodes=2:ppn=2
#PBS -t 1-100

ml icc
ml openmpi

cd $PBS_O_WORKDIR

mpirun -np 4 ./hello

./update_and_stagein.sh $PBS_ARRAYID
