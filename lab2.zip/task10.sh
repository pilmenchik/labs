#!/bin/bash
#PBS -N mpi_task10
#PBS -l nodes=2:ppn=2
#PBS -t 1-100

ml icc
ml openmpi

cd $PBS_O_WORKDIR

mpirun -np 4 ./hello > /tmp/output_$PBS_ARRAYID.txt

if (( $PBS_ARRAYID % 10 == 0 )); then
  ./manager_task.sh $PBS_ARRAYID
fi

if [ "$PBS_ARRAYID" -eq "100" ]; then
  ./final_manager_stats.sh
fi
