#!/bin/bash
for file in cache_*.txt; do
  cat $file >> final_cache.txt
done

for file in ~/output_*.txt; do
  cat $file >> final_output.txt
done

paste final_cache.txt final_output.txt > final_result.txt
